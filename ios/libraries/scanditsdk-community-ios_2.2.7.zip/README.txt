
Scandit SDK (Version 2.0.0 and higher) 

* ScanditSDKDemo is a (very) simple sample application which contains the Scandit SDK library. It was created to demonstrate the project setup needed to use the Scandit SDK in a more complex project.

To get started, check out the information on http://www.scandit.com. The web page provides information on how to

* build and run the ScanditSDKDemo project
* use the ScanditSDK in your own project
