
Scandit SDK (Version 3.0.0 and higher) 

To get started, check out the developer documentation at http://docs.scandit.com. The web page provides information on how to

* build and run the demo projects that come with the Scandit SDK. 
* use the Scandit SDK in your own project project. 
